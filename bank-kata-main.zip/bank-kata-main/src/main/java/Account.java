public class Account {

    void deposit(int amount) {

    }

    void withdraw(int amount){

    }

    void printStatements() {

    }

}
