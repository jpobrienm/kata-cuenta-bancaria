import org.junit.Test;

public class AcceptanceTest {

    @Test
    public void shouldWhatever() {

    }

}
